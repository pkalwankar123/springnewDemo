package com.cg.demomvcjavaconfig.dto;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


//Entity class created

@Entity
@Table(name="owner")
public class Owner {
	//Attributes//
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="owner_id")
	private int id;
	@Column(name="owner_name")
	private String name;
	@Column(name="mobnumber")
	private BigInteger mobNumber;
	/*
	@OneToMany(cascade=CascadeType.MERGE,mappedBy  = "owner" )
	private List<Vehicle> vehicles=new ArrayList<Vehicle>();
	*/
	
	 @OneToOne(cascade=CascadeType.ALL)
	    @JoinColumn(name="addid")
	 
	    private Address address;
	
	//Attributes//
	//Constructors//
	public Owner(){}

	public Owner(int id,String name, BigInteger mobNumber, Address address) {
		super();
		this.id=id;
		this.name = name;
		this.mobNumber = mobNumber;
		//this.vehicles = vehicles;
		this.address = address;
	}
	//Constructors//
	
	//Getter and setters//
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigInteger getmobNumber() {
		return mobNumber;
	}

	public void setmobNumber(BigInteger mobNumber) {
		this.mobNumber = mobNumber;
	}

	/*public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}*/

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	
	public String getOwnerDetails(){
		StringBuilder sb = new StringBuilder();	
		sb.append("id:-"+ this.id);
		sb.append(" ");
		sb.append("Owner:- "+this.name);
		sb.append(" ");
		sb.append("Mob no.:- "+this.mobNumber);
		sb.append(" ");
		sb.append(this.address.toString());
		sb.append(" ");
		/*for(Vehicle s : this.vehicles) {
			sb.append(s.vehicleDetails());
		}
		*/
		return sb.toString();
		
	}
	
	public String ownerDetails() {
		return this.id+""+ this.name + " "+ this.mobNumber + " "+ this.address.toString();
	}

	

	
}

