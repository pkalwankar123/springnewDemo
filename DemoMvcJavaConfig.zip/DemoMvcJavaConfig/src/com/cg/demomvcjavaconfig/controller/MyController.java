package com.cg.demomvcjavaconfig.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.demomvcjavaconfig.dto.Owner;
import com.cg.demomvcjavaconfig.dto.Product;
import com.cg.demomvcjavaconfig.dto.Vehicle;
import com.cg.demomvcjavaconfig.service.Ownerserviceinterface;
import com.cg.demomvcjavaconfig.service.ProductService;


@Controller
public class MyController {

	@Autowired
	ProductService productService;
	@Autowired
	Ownerserviceinterface ownerService;
	
	@GetMapping("login")
	public String loginPage()
	{
		return "listpage";
	}
	
	
	 @GetMapping("addOwnerr")
	 public ModelAndView getAddCustomer(@ModelAttribute("owner") Owner owe) {
		 
		 Map<String, Object> myMap = new HashMap<>();
		 Set<String> listOfArea = new HashSet<String>();
		 //List<String> listOfArea=new ArrayList<>();
		 listOfArea.add("Talwade");
		 listOfArea.add("Nigdi");
		 listOfArea.add("Katraj");
		 listOfArea.add("Pimpri");
		 listOfArea.add("Akurdi");
		 listOfArea.add("Pune");
		 listOfArea.add("Hinjawadi");
		 
		 Set<String> listOfCity = new HashSet<String>();
		 listOfCity.add("Pune");
		 listOfCity.add("Pimpri-Chinchwad");
		 listOfCity.add("Khed");
		 listOfCity.add("Katraj");
		 
		 
		 myMap.put("listofarea", listOfArea);
		 myMap.put("listofcity", listOfCity);
		 
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addowner", "details", myMap);
	 }
	
	 @PostMapping("addOwner")
	 public ModelAndView addCustomer(@ModelAttribute("owner") Owner ower) {
//		 System.out.println(pro);
		 Owner owner= ownerService.add(ower);
		 return new ModelAndView("success","key",owner);
	 }
	 
	 
	/* @GetMapping("addOwner")
	 public ModelAndView getAddCustomer(@ModelAttribute("vehicle") Vehicle vehic) {
		 
		 Map<String, Object> myMap = new HashMap<>();
		 Set<String> listOfArea = new HashSet<String>();
		 //List<String> listOfArea=new ArrayList<>();
		 listOfArea.add("Talwade");
		 listOfArea.add("Nigdi");
		 listOfArea.add("Katraj");
		 listOfArea.add("Pimpri");
		 listOfArea.add("Akurdi");
		 listOfArea.add("Pune");
		 listOfArea.add("Hinjawadi");
		 
		 Set<String> listOfCity = new HashSet<String>();
		 listOfCity.add("Pune");
		 listOfCity.add("Pimpri-Chinchwad");
		 listOfCity.add("Khed");
		 listOfCity.add("Katraj");
		 
		 
		 myMap.put("listofarea", listOfArea);
		 myMap.put("listofcity", listOfCity);
		 
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addowner", "details", myMap);
	 }
	*/
	 /*@PostMapping("addOwner")
	 public ModelAndView addCustomer(@ModelAttribute("vehicle") Vehicle vehic) {
//		 System.out.println(pro);
		 Owner owner= ownerService.add(ower);
		 return new ModelAndView("success","key",owner);
	 }
	 */
	 
	/* @GetMapping("addowner")
	 public ModelAndView getAddproduct(@ModelAttribute("owner") Owner OwnerOne) {
		 List<String> listOfCategory=new ArrayList<>();
		 listOfCategory.add("Electronics");
		 listOfCategory.add("Book");
		 listOfCategory.add("Cosmetics");
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addproduct", "cato", listOfCategory);
	 }*/
	 
	 
	
}
