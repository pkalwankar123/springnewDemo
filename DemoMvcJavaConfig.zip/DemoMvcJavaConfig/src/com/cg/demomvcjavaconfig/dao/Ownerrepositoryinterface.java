package com.cg.demomvcjavaconfig.dao;

import java.sql.SQLException;

import com.cg.demomvcjavaconfig.dto.Owner;


public interface Ownerrepositoryinterface {

	public Owner save(Owner owner);
	
	
}
