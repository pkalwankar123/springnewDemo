package com.cg.demomvcjavaconfig.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.demomvcjavaconfig.dto.Owner;



@Repository
public class OwnerrepositoryImp implements Ownerrepositoryinterface{
	@PersistenceContext
	EntityManager entitymanager;

	public Owner save(Owner owner){
		
		entitymanager.persist(owner);
		entitymanager.flush();
	return owner;
	}
	

}
