package com.cg.demomvcjavaconfig.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.demomvcjavaconfig.dto.Owner;
import com.cg.demomvcjavaconfig.dto.Vehicle;




public class VehiclerepositoryImp implements Vehiclerepositoryinterface{

	EntityManager em;
	public VehiclerepositoryImp() {
		//em=Dbutil.em;
	}
	
	
	public Vehicle save(Vehicle vehicle) {
		
		
		int owner_id=vehicle.getOwner().getId();
		
		
		
		
		Query queryOne  = em.createQuery("Select a From Owner a where owner_id= :owner_id");
		List<Owner> owner=queryOne.setParameter("owner_id", owner_id).getResultList();
		
		if(!(owner.isEmpty())) {
			em.getTransaction().begin();
			em.persist(vehicle);
			//em.merge(vehicle);
			em.getTransaction().commit();
			//em.close();
			
		}
		//em.persist(vehicle.getOwner());
		
		

	/*	else{
			throw new InvalidOwnerId("OOPS..Owner Not found into the Database."
					+ " Please enter the valid Owner number and try again!!");
		}
		 */
		
		return vehicle;
	}

	public List<Vehicle> findByVehNo(String vehNumber)
			{
		//List<Vehicle> depts;
		Query query  = em.createQuery("Select a From Vehicle a where vehicle_number= :vehNumber");
		 
		
		 List<Vehicle> depts=query.setParameter("vehNumber", vehNumber).getResultList();
		// veh.setnumber(number);
		// veh.setnumber(number);
		// depts.Vehicle.class).getResultList()

		
		return depts;
	}

	
}
