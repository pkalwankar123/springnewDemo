package com.cg.demomvcjavaconfig.service;

import java.sql.SQLException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demomvcjavaconfig.dao.OwnerrepositoryImp;
import com.cg.demomvcjavaconfig.dto.Owner;


@Service
@Transactional
public class OwnerserviceImp implements Ownerserviceinterface{
	
	@Autowired
	OwnerrepositoryImp owner;
	
	public Owner add(Owner owe) {
		

		return owner.save(owe);
	}
	
	
}
