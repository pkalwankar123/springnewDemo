package com.cg.demomvcjavaconfig.service;

import java.sql.SQLException;

import com.cg.demomvcjavaconfig.dto.Owner;


public interface Ownerserviceinterface {
public Owner add(Owner owe);
}
