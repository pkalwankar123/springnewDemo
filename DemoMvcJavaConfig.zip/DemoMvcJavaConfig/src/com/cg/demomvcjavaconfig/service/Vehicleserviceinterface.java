package com.cg.demomvcjavaconfig.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.demomvcjavaconfig.dto.Vehicle;



public interface Vehicleserviceinterface {


	public void add(Vehicle vehicle);
	public List<Vehicle> searchbyVehNo(String vehNo);

}
