package com.cg.parkingmanagementsys.ui;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.parkingmanagementsys.dto.Address;
import com.cg.parkingmanagementsys.dto.Owner;
import com.cg.parkingmanagementsys.dto.Parking;
import com.cg.parkingmanagementsys.dto.Parkingslot;
import com.cg.parkingmanagementsys.dto.Parktransaction;
import com.cg.parkingmanagementsys.dto.Vehicle;
import com.cg.parkingmanagementsys.exceptions.VehicleNotFoundException;

import com.cg.parkingmanagementsys.exceptions.invaliddetailexcepion;
import com.cg.parkingmanagementsys.service.Parkingservice;
import com.cg.parkingmanagementsys.service.Parkingslotservice;
import com.cg.parkingmanagementsys.service.Parkingtransservice;
import com.cg.parkingmanagementsys.service.VehicleServices;
import com.cg.parkingmanagementsys.util.DButil;

public class Myapplication {

	public static void main(String[] args) {
		
		VehicleServices vehsservice=new VehicleServices();
		Parkingservice parkservice=new Parkingservice();
		Parkingslotservice parkslotservice=new Parkingslotservice();
		Parkingtransservice parktrans=new Parkingtransservice();
		
		Owner ownerOne=new Owner();
		Owner ownerTwo=new Owner();
		Address address=new Address("B-443","Mankhurd","Mumbai",400088);
		Address addressOne=new Address("C-444","Nerul","NaviMumbai",4000706);
		
		
		
		ownerOne.setName("Pradip");	
		ownerOne.setMobNo(new BigInteger("7506271166"));	
		ownerOne.setAddress(address);

		ownerTwo.setName("Danish");	
		ownerTwo.setMobNo(new BigInteger("7776968917"));	
		ownerTwo.setAddress(addressOne);
			Vehicle vehice=new Vehicle(1,"MH03CA1256","Audi800",ownerOne);
			Vehicle vehiceOne=new Vehicle(2,"MH12BD5533","BMW-R8",ownerOne);
			
			Vehicle vehiceTwo=new Vehicle(1,"MH17CA9555","Hyundai-Verna",ownerTwo);
			Vehicle vehiceThree=new Vehicle(2,"MH11BD1241","Mitsubishi-Pajero",ownerTwo);
		List<Vehicle> veh=new ArrayList<Vehicle>();
		veh.add(vehice);
		veh.add(vehiceOne);
		ownerOne.setVehicles(veh);
		
		
		List<Vehicle> veh1=new ArrayList<Vehicle>();
		veh1.add(vehiceTwo);
		veh1.add(vehiceThree);
		ownerTwo.setVehicles(veh1);
		
		DButil.owner.add(ownerOne);
		DButil.owner.add(ownerTwo);
		
		
		Parking parking=new Parking(1,"Talwade",ownerOne);
		
		LocalTime startTime = LocalTime.of(8,30,15);
		LocalTime endTime = startTime.plusHours(8);
		LocalDate startDate = LocalDate.now();
		LocalDate endDate = LocalDate.now();
		
		Parkingslot parkingslot=new Parkingslot(1,parking,startDate,endDate,startTime,endTime);
int choice=0;
do{
		Scanner sc=new Scanner(System.in);
		System.out.println("================================================");
		System.out.println();
		System.out.println("========= Parking Management System ===========");
		System.out.println();
		System.out.println("================================================");
		System.out.println("=============== WELCOME ========================");
		System.out.println("1. Add Vehicles");
		System.out.println("2. Search Vehicles");
		System.out.println("3. Add Parking Location");
		System.out.println("4. Add Parkingslot");
		
		System.out.println("5. Assign Parking");
		System.out.println("6. Exit");
		System.out.println();
		System.out.println("================================================");
	
		choice=sc.nextInt();
		
		
		switch(choice){
			case 1: 
				vehsservice.add(vehice);
				vehsservice.add(vehiceOne);
				
				vehsservice.add(vehiceTwo);
				vehsservice.add(vehiceThree);
		
				System.out.println("================================");
				System.out.println();
				System.out.println("Vehicles Added successfully!!!!");
				System.out.println();
				System.out.println("=================================");
				
				for(Vehicle owe:DButil.vehicle){
					System.out.println("Vehicle ID :- "+owe.getVehId());
					System.out.println("Vehicle Number :- "+owe.getVehNo());
					System.out.println("Vehicle Description :- "+owe.getVehDesc());
				System.out.println("Owner detail related to vehicle :- "+owe.getOwner().getOwnerDetails());
				System.out.println("=================================");
				}
				break;
			case 2:
				System.out.println();
				System.out.println("=================================");
				System.out.println("Enter Vehicle number that you want too search");
				String vehNo=sc.next();
			Vehicle vehicle;
			try {
				vehicle = vehsservice.searchbyVehNo(vehNo);
				
				System.out.println("Here is your Vehicle detail...");
				System.out.println();
				System.out.println(vehicle.vehicleDetails());
				
			} catch (VehicleNotFoundException e) {
				
				System.out.println(e.getMessage());
			}
			System.out.println("=================================");
				break;
			case 3:
				System.out.println("=================================");
				parkservice.addParking(parking);
				
				System.out.println("Parking location Added successfullly!!!");
				System.out.println();
				for(Parking owe:DButil.parking){
					System.out.println("Parking id:- "+owe.getId());
					System.out.println("Parking Location:- "+owe.getLocation());
					
					
				System.out.println("Owner Detail:- "+owe.getOwner().getOwnerDetails());
				System.out.println("=================================");
				}
				break;
case 4:
	System.out.println("=================================");
	parkslotservice.createParkingslot(parkingslot);
	
				System.out.println("Parking slot created successfullly");
				System.out.println();
				for(Parkingslot owe:DButil.parkingslot){
					System.out.println("ParkingSlot ID:- "+owe.getId());
					System.out.println("Parkingslot for "+owe.getParking());
					System.out.print("ParkingSlot creator detail:- "+owe.getParking().getOwner().ownerDetails());
					System.out.println();
					System.out.println("Start date of parkingslot:- "+owe.getStartDate());
					System.out.println("End date of parkingslot:- "+owe.getEndDate());
					System.out.println("Start time of parkingslot:- "+owe.getStartTime());
					System.out.println("End time of parkingslot:- "+owe.getEndTime());						
					System.out.println();
					System.out.println("=================================");
				}
				break;
				

				
case 5:
			char ch;
			do {
		
	
	System.out.println("=================================");
	System.out.println();
	System.out.println("Enter parking id");
	int id=sc.nextInt();
	System.out.println();
	System.out.println("Enter Vehicle number");
	String vehNoone=sc.next();

	System.out.println("Enter time slot, start time in hrs and minutes:");
			System.out.println("eg. for 10:30 enter 10 hr then press 'Enter key' and enter the minutes 30 ");
	int pattern=sc.nextInt();

	
	int patterntwo=sc.nextInt();
	
	System.out.println("Till how many hrs you want to park vehicle");
	int patternOne=sc.nextInt();

	
	System.out.println();
	Vehicle vehicle1=new Vehicle();
	Parkingslot park=new Parkingslot();
	
	for(Vehicle vehic:DButil.vehicle){
		for(Parkingslot par:DButil.parkingslot){
			if((vehic.getVehNo().equals(vehNoone))&& (par.getId()==id)) {
				vehicle1=vehic;
				park=par;
				
						}
		}
	}
	try {
		if(vehicle1.getVehNo()==null || park.getId()!=id){
		throw new invaliddetailexcepion("OOPS!!..You have entered the wrong ID or Vehicle Number."
				+ "Please enter the valid detail and try again!!!");}
	} catch (invaliddetailexcepion e) {
		
		System.out.println(e.getMessage());
		break;
	}
		LocalTime startTime1 = LocalTime.of(pattern, patterntwo);
		LocalTime endTime1 = startTime1.plusHours(patternOne);
	
	
	
		
		LocalDate startDate1 = LocalDate.now();
		LocalDate endDate1 = LocalDate.now();


	Parktransaction parktranss=new Parktransaction(1,park,vehicle1,startDate1,endDate1,startTime1,endTime1);
	
	
	
			try {
				parktrans.bookParking(parktranss);
				
			} catch (invaliddetailexcepion e) {
				
				System.out.println(e.getMessage());
				break;
			}
				
				System.out.println("Parking assigned to below users successfullly..!!!");
				
				for(Parktransaction owe:DButil.parktrans){
					System.out.println("Parking transaction ID:- "+owe.getId());
					System.out.println(owe.getPk());
					System.out.print(owe.getVeh().vehicleDetails());
					System.out.println();
					System.out.println("Start date:- "+owe.getStartDate());
					System.out.println("End date:- "+owe.getEndDate());
					System.out.println("Start Time:- "+owe.getStartTime());
					System.out.println("End Time:- "+owe.getEndTime());
					System.out.println();			
				}
				System.out.println("================================================");
				
				System.out.println("Do you want to assign another vehicle??  Y/N");
				ch=sc.next().charAt(0);
				System.out.println();
		}while(ch=='Y'||ch=='y');
				break;
				
case 6:
	System.out.println("======= Thank you ======");
	System.exit(0);
			break;
			
			default:
				System.out.println("Oops..Invalid input."
						+ "Please enter the correct choice from the list!!!");
		}
		
	}while(choice!=6);

}}

