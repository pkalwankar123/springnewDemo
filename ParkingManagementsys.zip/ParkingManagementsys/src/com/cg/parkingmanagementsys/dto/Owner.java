package com.cg.parkingmanagementsys.dto;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

public class Owner {

	private String name;
	private BigInteger mobNo;
	private List<Vehicle> vehicles;
	private Address address;
	
	public Owner(){}

	public Owner(String name, BigInteger mobNo, List<Vehicle> vehicles, Address address) {
		super();
		this.name = name;
		this.mobNo = mobNo;
		this.vehicles = vehicles;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigInteger getMobNo() {
		return mobNo;
	}

	public void setMobNo(BigInteger mobNo) {
		this.mobNo = mobNo;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	
	public String getOwnerDetails(){
		StringBuilder sb = new StringBuilder();	
		sb.append("Owner:- "+this.name);
		sb.append(" ");
		sb.append("Mob no.:- "+this.mobNo);
		sb.append(" ");
		sb.append(this.address.toString());
		sb.append(" ");
		for(Vehicle s : this.vehicles) {
			sb.append(s.vehicleDetails());
		}
		
		return sb.toString();
		
	}
	
	public String ownerDetails() {
		return this.name + " "+ this.mobNo + " "+ this.address.toString();
	}

	

	
}

