package com.cg.parkingmanagementsys.service;

import com.cg.parkingmanagementsys.dao.Parkingdao;
import com.cg.parkingmanagementsys.dto.Parking;

public class Parkingservice implements Parkingserviceinterface{

	
	Parkingdao parkdao;
	public Parkingservice(){
		parkdao=new Parkingdao();
	}
	
	
	@Override
	public void addParking(Parking parking) {
		// TODO Auto-generated method stub
		parkdao.save(parking);
	}

}

