package com.cg.parkingmanagementsys.service;

import com.cg.parkingmanagementsys.dto.Vehicle;
import com.cg.parkingmanagementsys.exceptions.VehicleNotFoundException;


public interface Vehicleservice {

	public void add(Vehicle vehicle);
	public Vehicle searchbyVehNo(String vehNo) throws VehicleNotFoundException;
}
