package com.cg.parkingmanagementsys.service;

import com.cg.parkingmanagementsys.dao.Parktransdao;
import com.cg.parkingmanagementsys.dto.Parktransaction;
import com.cg.parkingmanagementsys.exceptions.invaliddetailexcepion;

public class Parkingtransservice implements Parkingtransserivceinterface{
	Parktransdao parktrans;
	
	public Parkingtransservice(){
		parktrans=new Parktransdao();
	}
	@Override
	public void bookParking(Parktransaction parktrans1) throws invaliddetailexcepion{
		
		
		parktrans.book(parktrans1);
	}

}
