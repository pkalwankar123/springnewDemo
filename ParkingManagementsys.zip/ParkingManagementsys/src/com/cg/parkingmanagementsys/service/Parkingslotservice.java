package com.cg.parkingmanagementsys.service;

import java.util.Date;

import com.cg.parkingmanagementsys.dao.Parkingslotdaoclass;
import com.cg.parkingmanagementsys.dto.Parkingslot;

public class Parkingslotservice implements Parkingslotinterface{

	Parkingslotdaoclass parkslot;
	
	public Parkingslotservice(){
		parkslot=new Parkingslotdaoclass();
	}
	
	@Override
	public void createParkingslot(Parkingslot parkingslot) {

		parkslot.create(parkingslot);
	}

	@Override
	public Parkingslot searchbydate(Date date) {

		return null;
	}

}

