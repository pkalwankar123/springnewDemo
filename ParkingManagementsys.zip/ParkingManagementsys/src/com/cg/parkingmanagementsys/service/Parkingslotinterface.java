package com.cg.parkingmanagementsys.service;

import java.util.Date;

import com.cg.parkingmanagementsys.dto.Parkingslot;

public interface Parkingslotinterface {

	public void createParkingslot(Parkingslot parkingslot);
	
	public  Parkingslot searchbydate(Date date);
	
}
