package com.cg.parkingmanagementsys.service;

import com.cg.parkingmanagementsys.dto.Parktransaction;
import com.cg.parkingmanagementsys.exceptions.invaliddetailexcepion;

public interface Parkingtransserivceinterface {

	public void bookParking(Parktransaction parktrans) throws invaliddetailexcepion;
	
}
