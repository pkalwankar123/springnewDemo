package com.cg.parkingmanagementsys.service;

import com.cg.parkingmanagementsys.dao.Vehicledao;
import com.cg.parkingmanagementsys.dto.Vehicle;
import com.cg.parkingmanagementsys.exceptions.VehicleNotFoundException;


public class VehicleServices implements Vehicleservice{
	Vehicledao vehdao;

	public VehicleServices(){
		vehdao=new Vehicledao();
	}
	
	@Override
	public void add(Vehicle vehicle) {
		
		vehdao.save(vehicle);
	}

	@Override
	public Vehicle searchbyVehNo(String vehNo) throws VehicleNotFoundException {
		
		if(vehdao.findByVehNo(vehNo)==null){
			throw new VehicleNotFoundException("OOPS..Vehicle Not found into the Database."
					+ " Please enter the valid vehicle number and try again!!");
		
		}else
		
			return vehdao.findByVehNo(vehNo);
	}

}
