package com.cg.parkingmanagementsys.service;

import com.cg.parkingmanagementsys.dto.Parking;

public interface Parkingserviceinterface {

	public void addParking(Parking parking);
	
}
