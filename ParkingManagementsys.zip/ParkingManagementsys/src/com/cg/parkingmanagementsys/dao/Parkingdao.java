package com.cg.parkingmanagementsys.dao;

import com.cg.parkingmanagementsys.dto.Parking;
import com.cg.parkingmanagementsys.util.DButil;

public class Parkingdao implements Parkingdaointerface{

	@Override
	public Parking save(Parking park) {
		// TODO Auto-generated method stub
		DButil.parking.add(park);
		
		return park;
	}

}