package com.cg.parkingmanagementsys.dao;

import com.cg.parkingmanagementsys.dto.Vehicle;
import com.cg.parkingmanagementsys.util.DButil;

public class Vehicledao implements Vehicledaointerface{

	
	
	
	@Override
	public Vehicle save(Vehicle vehicle) {
	
		

		
DButil.vehicle.add(vehicle);

		
		return vehicle;
	}


	@Override
	public Vehicle findByVehNo(String vehNo) {
		// TODO Auto-generated method stub
		
		for(Vehicle veh: DButil.vehicle){
			if(veh.getVehNo().equals(vehNo)){
				return veh;
			}
		}
		
		
		return null;
	}
	

}