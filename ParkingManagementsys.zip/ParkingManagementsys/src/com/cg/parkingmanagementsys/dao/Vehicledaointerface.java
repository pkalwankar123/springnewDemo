package com.cg.parkingmanagementsys.dao;

import com.cg.parkingmanagementsys.dto.Vehicle;

public interface Vehicledaointerface {
public Vehicle save(Vehicle vehicle);
public Vehicle findByVehNo(String vehNo);

}
