package com.cg.parkingmanagementsys.dao;

import com.cg.parkingmanagementsys.dto.Parkingslot;
import com.cg.parkingmanagementsys.dto.Parktransaction;
import com.cg.parkingmanagementsys.dto.Vehicle;
import com.cg.parkingmanagementsys.exceptions.invaliddetailexcepion;
import com.cg.parkingmanagementsys.util.DButil;

public class Parktransdao implements Parkingttransdaointerface{

	@Override
	public Parktransaction book(Parktransaction parktrans1) throws invaliddetailexcepion{

		for(Parkingslot parkk: DButil.parkingslot) {
			if (((parktrans1.getStartTime()).isBefore(parkk.getStartTime())) || ((parktrans1.getStartTime()).isAfter(parkk.getEndTime())) )  {
				
				
				
				throw new invaliddetailexcepion("OOPS..Slot is not available, Please enter the timings between "+(parkk.getStartTime())+" to "+(parkk.getEndTime()));
				}
			
			}
		
		
			for(Parktransaction owe1:DButil.parktrans){
				
				
				if ((((parktrans1.getStartTime()).isAfter(owe1.getStartTime())) && ((parktrans1.getStartTime()).isBefore(owe1.getEndTime())) ) || ((owe1.getStartTime().equals(parktrans1.getStartTime())) || (owe1.getEndTime().equals(parktrans1.getEndTime())))) {
				
					
					
						throw new invaliddetailexcepion("OOPS..Slot is alreaddy booked between "+owe1.getStartTime()+" to "+owe1.getEndTime());
						}
				
			}
		
		
		DButil.parktrans.add(parktrans1);
		
		return parktrans1;
	}

}
