package com.cg.parkingmanagementsys.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.parkingmanagementsys.dto.Owner;
import com.cg.parkingmanagementsys.dto.Parking;
import com.cg.parkingmanagementsys.dto.Parkingslot;
import com.cg.parkingmanagementsys.dto.Parktransaction;
import com.cg.parkingmanagementsys.dto.Vehicle;

public class DButil {

	public static List<Owner> owner=new ArrayList<Owner>();
	public static List<Vehicle> vehicle=new ArrayList<Vehicle>();
	public static List<Parking> parking=new ArrayList<Parking>();
	public static List<Parkingslot> parkingslot=new ArrayList<Parkingslot>();
	public static List<Parktransaction> parktrans=new ArrayList<Parktransaction>();
	
}
