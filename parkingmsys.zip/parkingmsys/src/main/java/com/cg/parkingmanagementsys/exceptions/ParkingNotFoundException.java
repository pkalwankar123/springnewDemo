package com.cg.parkingmanagementsys.exceptions;

public class ParkingNotFoundException extends Exception {

	public ParkingNotFoundException(){}
	public ParkingNotFoundException(String msg){
		super(msg);
	}
	}
