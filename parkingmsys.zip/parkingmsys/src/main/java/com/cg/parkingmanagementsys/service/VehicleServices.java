package com.cg.parkingmanagementsys.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.parkingmanagementsys.dao.Vehicledao;
import com.cg.parkingmanagementsys.dto.Vehicle;
import com.cg.parkingmanagementsys.exception.InvalidOwnerId;
import com.cg.parkingmanagementsys.exception.InvaliddetailId;
import com.cg.parkingmanagementsys.exceptions.VehicleNotFoundException;


public class VehicleServices implements Vehicleservice {
	Vehicledao vehdao;

	public VehicleServices(){
		vehdao=new Vehicledao();
	}
	
	
	public void add(Vehicle vehicle) throws InvaliddetailId, SQLException {
		
		vehdao.save(vehicle);
	}

	public List<Vehicle> searchbyVehNo(String vehNo) throws VehicleNotFoundException, SQLException {
		
		if(vehdao.findByVehNo(vehNo)==null){
			throw new VehicleNotFoundException("OOPS..Vehicle Not found into the Database."
					+ " Please enter the valid vehicle number and try again!!");
		
		}else
		
			return vehdao.findByVehNo(vehNo);
	}


}
