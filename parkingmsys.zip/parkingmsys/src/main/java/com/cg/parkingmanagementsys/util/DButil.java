package com.cg.parkingmanagementsys.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;


import com.cg.parkingmanagementsys.dto.Owner;
import com.cg.parkingmanagementsys.dto.Parking;
import com.cg.parkingmanagementsys.dto.Parkingslot;
import com.cg.parkingmanagementsys.dto.Parktransaction;
import com.cg.parkingmanagementsys.dto.Vehicle;

public class DButil {

	
	
	static Connection conn;

	public static Connection getConnection(){
		
		Properties prop=new Properties();
		FileInputStream it=null;
		try {
			it=new FileInputStream("src/main/resources/jdbc.properties");
			
			prop.load(it);
			
			if(conn==null) {
if(prop!=null) {
	
	
	String driver=prop.getProperty("jdbc.driver");
	String url=prop.getProperty("jdbc.url");
	String uname=prop.getProperty("jdbc.username");
	String upass=prop.getProperty("jdbc.password");
	
	//Class.forName(driver);
	
	conn=DriverManager.getConnection(url,uname,upass);
}
			}
		}catch(FileNotFoundException e) {
			e.printStackTrace();
			
			//throw new EmployeeException("File not found");
			
		}catch(IOException e) {
			e.printStackTrace();
			//throw new EmployeeException("File not found");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
		
	}
	
	
	
	
	
	
	public static List<Owner> owner=new ArrayList<Owner>();
	public static List<Vehicle> vehicle=new ArrayList<Vehicle>();
	public static List<Parking> parking=new ArrayList<Parking>();
	public static List<Parkingslot> parkingslot=new ArrayList<Parkingslot>();
	public static List<Parktransaction> parktrans=new ArrayList<Parktransaction>();
	
}
