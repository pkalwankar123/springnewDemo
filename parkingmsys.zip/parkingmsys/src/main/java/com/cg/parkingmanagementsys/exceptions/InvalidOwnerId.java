package com.cg.parkingmanagementsys.exceptions;

public class InvalidOwnerId extends Exception{

public InvalidOwnerId() {}
	
	public InvalidOwnerId(String msg) {
		super(msg);
	}
	
}

