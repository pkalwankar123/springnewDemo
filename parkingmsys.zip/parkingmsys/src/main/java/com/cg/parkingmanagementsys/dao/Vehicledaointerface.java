package com.cg.parkingmanagementsys.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.parkingmanagementsys.dto.Vehicle;
import com.cg.parkingmanagementsys.exception.InvalidOwnerId;
import com.cg.parkingmanagementsys.exception.InvaliddetailId;
import com.cg.parkingmanagementsys.exceptions.VehicleNotFoundException;

public interface Vehicledaointerface {
	public Vehicle save(Vehicle vehicle) throws InvaliddetailId, SQLException;
	public List<Vehicle> findByVehNo(String vehNo) throws VehicleNotFoundException, SQLException;


}
