package com.cg.parkingmanagementsys.exception;

public class InvalidOwnerId extends Exception {

	public InvalidOwnerId() {}
	
	public InvalidOwnerId(String msg) {
		super(msg);
	}
	
}
