package com.cg.parkingmanagementsys.exceptions;

public class invalidtimeexception extends Exception {

	public invalidtimeexception(){}
	
	public invalidtimeexception(String message){
		super(message);
	}
}
