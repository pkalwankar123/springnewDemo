package com.cg.parkingmanagementsys.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.parkingmanagementsys.dto.Parking;
import com.cg.parkingmanagementsys.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsys.util.DButil;

public class Parkingdao implements Parkingdaointerface{


	public Parking save(Parking park) throws InvaliddetailId {


		
		
		Connection con=DButil.getConnection();
		String query_insert="Insert into parking(id,location,owid) values(?,?,?)";
		String query="Select id from owner where id=?";
		String queryOne="Select id from parking where id=?";
		PreparedStatement pstmone=null;
		PreparedStatement pstm=null;
		PreparedStatement pstmOne=null;
		try {
	
			
			
			pstm=con.prepareStatement(query);
			pstm.setInt(1, park.getOwner().getId());
			ResultSet rs1=pstm.executeQuery();
			
			pstmOne=con.prepareStatement(queryOne);
			pstmOne.setInt(1, park.getId());
			ResultSet rs=pstmOne.executeQuery();
			
		if(rs1.next()==true) {	
		if(rs.next()==false){
			pstmone=con.prepareStatement(query_insert);
			pstmone.setInt(1, park.getId());
			pstmone.setString(2, park.getLocation());
			pstmone.setInt(3, park.getOwner().getId());
				pstmone.executeUpdate();
			
			
			
			}else {
				throw new InvaliddetailId("OOPs, this ParkingID already used. Kindly enter the another Parking id!!");
				
			}
		
		
		
		}
		
			
			else {
				throw new InvaliddetailId("OOPs, You have entered the wrong owner ID. Kindly enter the correct owner id!!");
			}
		
		}
	catch(SQLException e) {
		e.printStackTrace();
			
		}
	return park;	
		
	}
	
}


