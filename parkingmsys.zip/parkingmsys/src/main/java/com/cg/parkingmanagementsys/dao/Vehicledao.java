package com.cg.parkingmanagementsys.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.parkingmanagementsys.dto.Address;
import com.cg.parkingmanagementsys.dto.Owner;
import com.cg.parkingmanagementsys.dto.Vehicle;
import com.cg.parkingmanagementsys.exception.InvalidOwnerId;
import com.cg.parkingmanagementsys.exception.InvaliddetailId;
import com.cg.parkingmanagementsys.exceptions.VehicleNotFoundException;
import com.cg.parkingmanagementsys.util.DButil;

public class Vehicledao implements Vehicledaointerface{

	
	static Connection con;
	
	
	public Vehicle save(Vehicle vehicle) throws InvaliddetailId, SQLException  {
	
		
	
			
			
			
			con=DButil.getConnection();
			String query_insert="Insert into vehicle(vehid,vehno,vedesc,owid) values(?,?,?,?)";
			String query="Select id from owner where id=?";
			String queryOne="Select vehid from vehicle where vehid=?";
			PreparedStatement pstmone=null;
			PreparedStatement pstm=null;
			PreparedStatement pstmOne=null;
			try {
		
				
				
				pstm=con.prepareStatement(query);
				pstm.setInt(1, vehicle.getOwner().getId());
				ResultSet rs1=pstm.executeQuery();
				
				pstmOne=con.prepareStatement(queryOne);
				pstmOne.setInt(1, vehicle.getVehId());
				ResultSet rs=pstmOne.executeQuery();
				
			if(rs1.next()==true) {	
			if(rs.next()==false){
				pstmone=con.prepareStatement(query_insert);
				pstmone.setInt(1, vehicle.getVehId());
				pstmone.setString(2, vehicle.getVehNo());
				pstmone.setString(3, vehicle.getVehDesc());
				pstmone.setInt(4, vehicle.getOwner().getId());
				pstmone.executeUpdate();
				
				//if(rs.next()==true){	
					//if(vehicle.getVehId()!=rs.getInt(1) ){
						
							
					//}
				
				}else {
					throw new InvaliddetailId("OOPs, this vehID already used. Kindly enter the another vehicle id!!");
					
				}
			
			
			
			}
			
				
				else {
					throw new InvaliddetailId("OOPs, You have entered the wrong owner ID. Kindly enter the correct owner id!!");
				}
			
			}
		catch(SQLException e) {
			e.printStackTrace();
				
			}
			
			
		return vehicle;	
			
		}
			
			
			



	public List<Vehicle> findByVehNo(String vehNo) throws VehicleNotFoundException{
		

		
Connection con1;
PreparedStatement pstm=null;	

Vehicle veh=new Vehicle();
	List<Vehicle> vehe=new ArrayList<Vehicle>();	
try {
	
	
	
	
	
	con1=DButil.getConnection();
	String query_Show="Select a.addid,a.houseno,a.street,a.city,a.pincode,o.id,o.name,o.mobno,v.vehid,v.vehno,v.vedesc from owner o join address a on o.id=a.addid join vehicle v on o.id=v.owid where v.vehno=?";
	
	
	
			
			
	
			pstm=con1.prepareStatement(query_Show);
			pstm.setString(1, vehNo);
			ResultSet result=pstm.executeQuery();
			
			
			
			while(result.next()) {
				
				Owner owe=new Owner();
			Address add=new Address();
			add.setAddid(result.getInt(1));	
			add.setHouseNo(result.getString(2));
			add.setStreet(result.getString(3));
			add.setCity(result.getString(4));
			add.setPincode(result.getInt(5));
			
			owe.setId(result.getInt(6));
			owe.setName(result.getString(7));
			owe.setMobNo(new BigInteger(result.getString(8)));
			owe.setAddress(add);
			
			veh.setVehId(result.getInt(9));
				veh.setVehNo(result.getString(10));
				veh.setVehDesc(result.getString(11));
				
				
				
				
				
				veh.setOwner(owe);;
				vehe.add(veh);

				
			}
		
		
		
			
		
		
	}
catch(SQLException e) {
	e.printStackTrace();
		
	}
if(vehe.isEmpty()){
	throw new VehicleNotFoundException("OOPS..Vehicle Not found into the Database."
			+ " Please enter the valid vehicle number and try again!!");

}
else{
return vehe;
}

}}

