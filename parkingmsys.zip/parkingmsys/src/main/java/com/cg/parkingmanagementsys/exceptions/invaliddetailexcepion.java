package com.cg.parkingmanagementsys.exceptions;

public class invaliddetailexcepion extends Exception {

	public invaliddetailexcepion(){}
	
	public invaliddetailexcepion(String message){
		super(message);
	}
	
}
