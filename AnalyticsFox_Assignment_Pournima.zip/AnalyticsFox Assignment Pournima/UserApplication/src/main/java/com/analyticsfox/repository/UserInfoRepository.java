package com.analyticsfox.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.analyticsfox.model.UserDetails;

@Repository
public interface UserInfoRepository extends JpaRepository<UserDetails, String>{
	
	UserDetails findByEmail(String email);
	UserDetails findByContact(String contact);


}
