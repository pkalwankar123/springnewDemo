package com.analyticsfox.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.analyticsfox.model.UserDetails;
import com.analyticsfox.model.UserRequest;
import com.analyticsfox.repository.UserInfoRepository;

/**
 * @author Pournima
 *
 */
@Service
public class UserDetailsService {

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Autowired
	UserInfoRepository userInfoRepo;

	public UserDetails processUserDetails(UserRequest userReq) {

		String uri = "https://api.postalpincode.in/pincode/";
		Log logger = LogFactory.getLog(UserDetailsService.class);
		uri = uri + userReq.getPincode();

		JSONArray responseArray = null;
		try {
			responseArray = new JSONArray(restTemplate().getForObject(uri, String.class));
		} catch (Exception e) {
			
			logger.error("No Json data received");
		}
		
		
		
		UserDetails userInfo = new UserDetails();
		if (responseArray != null && !responseArray.isEmpty()) {
			JSONObject jsonObj = responseArray.getJSONObject(0);

			if ("Success".equals(jsonObj.getString("Status"))) {
				JSONArray postOfficeArray = jsonObj.getJSONArray("PostOffice");
				JSONObject postOffice = postOfficeArray.getJSONObject(0);

				userInfo.setName(userReq.getName());
				userInfo.setContact(userReq.getContact());
				userInfo.setEmail(userReq.getEmail());
				userInfo.setPincode(userReq.getPincode());
				userInfo.setDistrict(postOffice.getString("District"));
				userInfo.setState(postOffice.getString("State"));
				userInfo.setRegion(postOffice.getString("Region"));
				userInfo.setCountry(postOffice.getString("Region"));

				userInfoRepo.save(userInfo);

			}
		}

		return userInfo;
	}

	public UserDetails getUserDetailsByEmail(UserRequest userReq) {

		return userInfoRepo.findByEmail(userReq.getEmail());

	}

	public UserDetails getUserDetailsByContact(UserRequest userReq) {

		return userInfoRepo.findByContact(userReq.getContact());

	}

}
