package com.analyticsfox.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.analyticsfox.model.UserDetails;
import com.analyticsfox.model.UserRequest;
import com.analyticsfox.model.UserResponse;
import com.analyticsfox.service.UserDetailsService;

@RestController
@RequestMapping("/userApp")
public class UserDetailsController {
	
	Log logger = LogFactory.getLog(UserDetailsController.class);

	@Autowired
	UserDetailsService userDetailService;

	@PostMapping("/postUserDetails")
	public UserResponse postUserDetails(@RequestBody UserRequest userReq) {

		logger.info("In postUserDetails method");

		// Validation of params considering all request params are mandetory
		if (validateRequestParams(userReq) != null) {
			return validateRequestParams(userReq);
		}

		UserDetails userInfo = userDetailService.processUserDetails(userReq);

		return prepareResponse(userInfo);

//		return userReq.getName();

	}


	@GetMapping("/getUserDetailsByEmail")
	public UserResponse getUserDetailsByEmail(@RequestBody UserRequest userReq) {
		logger.info("In getUserDetailsByEmail method");
		return prepareResponse(userDetailService.getUserDetailsByEmail(userReq));

	}

	@PostMapping("/getUserDetailsByContact")
	public UserResponse getUserDetailsByContact(@RequestBody UserRequest userReq) {
		logger.info("In getUserDetailsByContact method");

		return prepareResponse(userDetailService.getUserDetailsByContact(userReq));

	}
	
	

	private UserResponse validateRequestParams(UserRequest userReq) {
		if (userReq != null) {
			if (StringUtils.isEmpty(userReq.getName()) || StringUtils.isEmpty(userReq.getContact())
					|| StringUtils.isEmpty(userReq.getEmail()) || StringUtils.isEmpty(userReq.getPincode())) {
				
				logger.error("Invalid Request params");
				return new UserResponse("Invalid Request");
			}

		} else {
			return new UserResponse("Invalid Request");

		}
		return null;

	}
	
	
	private UserResponse prepareResponse(UserDetails userInfo) {
		UserResponse userResponse = new UserResponse();
		userResponse.setStatus("Success");
		userResponse.setName(userInfo.getName());
		userResponse.setContact(userInfo.getContact());
		userResponse.setEmail(userInfo.getEmail());
		userResponse.setPincode(userInfo.getPincode());
		userResponse.setDistrict(userInfo.getDistrict());
		userResponse.setRegion(userInfo.getRegion());
		userResponse.setState(userInfo.getState());
		userResponse.setCountry(userInfo.getCountry());

		return userResponse;
	}

}
