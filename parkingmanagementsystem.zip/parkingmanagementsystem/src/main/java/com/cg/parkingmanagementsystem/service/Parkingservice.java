package com.cg.parkingmanagementsystem.service;

import com.cg.parkingmanagementsystem.dao.Parkingdao;
import com.cg.parkingmanagementsystem.dto.Parking;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;

public class Parkingservice implements Parkingserviceinterface{

	
	Parkingdao parkdao;
	public Parkingservice(){
		parkdao=new Parkingdao();
	}
	
	
	public void addParking(Parking parking) throws InvaliddetailId, InvalidOwnerId {

		parkdao.save(parking);
	}


}

