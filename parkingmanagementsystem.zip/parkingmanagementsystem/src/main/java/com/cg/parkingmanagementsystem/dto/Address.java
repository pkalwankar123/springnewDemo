package com.cg.parkingmanagementsystem.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class Address {
	
	//Attributes//
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="addid")
	private int id;
	@Column(name="housenumber")
	private String houseNumber;
	@Column(name="street")
	private String street;
	@Column(name="city")
	private String city;
	@Column(name="pincode")
	private int pincode;
	//Attributes//
	
	
	
	
	//Constructors//
	public Address() {}
	
	
public Address(int id,String houseNumber, String street, String city, int pincode) {
		super();
		this.id=id;
		this.houseNumber = houseNumber;
		this.street = street;
		this.city = city;
		this.pincode = pincode;
	}
//Constructors//

//Getter and setters//

public int getid() {
	return id;
}
public void setid(int id) {
	this.id = id;
}
public String getHouseNumber() {
	return houseNumber;
}
public void sethouseNumber(String houseNumber) {
	this.houseNumber = houseNumber;
}
public String getstreet() {
	return street;
}
public void setstreet(String street) {
	street = street;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getPincode() {
	return pincode;
}
public void setPincode(int pincode) {
	this.pincode = pincode;
}


//Tostring method//
@Override
public String toString() {
	return "Address [houseNumber=" + houseNumber + ", id=" + id + ", street=" + street + ", city=" + city + ", pincode="
			+ pincode + "]";
}




}
