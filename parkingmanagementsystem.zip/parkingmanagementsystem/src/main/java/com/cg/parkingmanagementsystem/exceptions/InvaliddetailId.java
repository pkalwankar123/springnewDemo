package com.cg.parkingmanagementsystem.exceptions;

public class InvaliddetailId extends Exception {

public InvaliddetailId() {}
	
	public InvaliddetailId(String msg) {
		super(msg);
	}
	
	
}

