package com.cg.parkingmanagementsystem.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.parkingmanagementsystem.dto.Vehicle;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.VehicleNotFoundException;


public interface Vehicleserviceinterface {


	public void add(Vehicle vehicle) throws  InvaliddetailId, SQLException, InvalidOwnerId;
	public List<Vehicle> searchbyVehNo(String vehNo) throws VehicleNotFoundException, SQLException;

}
