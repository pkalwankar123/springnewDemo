package com.cg.parkingmanagementsystem.dto;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="Parktransaction")
	public class Parktransaction {
		//Attributes//
	@Id
	@Column(name="parkingtransaction_id")
		private int id;
	
	
	@OneToOne(cascade=CascadeType.MERGE)
    @JoinColumn(name="parkingslot_id")
		private Parkingslot parkingslot;
	
	@OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="vehicle_id")
		private Vehicle vehicle;
	
	@Column(name="startdate")
		private LocalDate startDate;
	@Column(name="enddate")
		private LocalDate endDate;
		
	@Column(name="starttime")
		private LocalTime startTime;
		
	@Column(name="endtime")	
	private LocalTime endTime;

		//Constructors//
		public Parktransaction() {}

		public Parktransaction(int id, Parkingslot parkingslot, Vehicle vehicle, LocalDate startDate, LocalDate endDate,
				LocalTime startTime, LocalTime endTime) {
			super();
			this.id = id;
			this.parkingslot = parkingslot;
			this.vehicle = vehicle;
			this.startDate = startDate;
			this.endDate = endDate;
			this.startTime = startTime;
			this.endTime = endTime;
		}

		
		//Getter and setters//
		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public Parkingslot getparkingslot() {
			return parkingslot;
		}

		public void setPk(Parkingslot parkingslot) {
			this.parkingslot = parkingslot;
		}

		public Vehicle getvehicle() {
			return vehicle;
		}

		public void setVeh(Vehicle vehicle) {
			this.vehicle = vehicle;
		}

		public LocalDate getStartDate() {
			return startDate;
		}

		public void setStartDate(LocalDate startDate) {
			this.startDate = startDate;
		}

		public LocalDate getEndDate() {
			return endDate;
		}

		public void setEndDate(LocalDate endDate) {
			this.endDate = endDate;
		}

		public LocalTime getStartTime() {
			return startTime;
		}

		public void setStartTime(LocalTime startTime) {
			this.startTime = startTime;
		}

		public LocalTime getEndTime() {
			return endTime;
		}

		public void setEndTime(LocalTime endTime) {
			this.endTime = endTime;
		}

		@Override
		public String toString() {
			return "Parktransaction [id=" + id + ", pk=" + parkingslot + ", veh=" + vehicle + ", startDate=" + startDate + ", endDate="
					+ endDate + ", startTime=" + startTime + ", endTime=" + endTime + "]";
		}

		
	
	}

