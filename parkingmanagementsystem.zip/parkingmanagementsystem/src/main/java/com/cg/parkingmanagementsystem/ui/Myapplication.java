package com.cg.parkingmanagementsystem.ui;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.cg.parkingmanagementsystem.dto.Address;
import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.dto.Parking;
import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.dto.Parktransaction;
import com.cg.parkingmanagementsystem.dto.Vehicle;
//import com.cg.parkingmanagementsystem.exception.InvalidOwnerId;
//import com.cg.parkingmanagementsystem.exception.InvaliddetailId;
//import com.cg.parkingmanagementsystem.exception.duplicateaddressuserexception;
//import com.cg.parkingmanagementsystem.util.Dbutil;
import com.cg.parkingmanagementsystem.exceptions.Duplicateaddressuserexception;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.ParkingNotFoundException;
import com.cg.parkingmanagementsystem.exceptions.VehicleNotFoundException;
import com.cg.parkingmanagementsystem.exceptions.invaliddetailexcepion;
import com.cg.parkingmanagementsystem.service.Ownerservice;
import com.cg.parkingmanagementsystem.service.Parkingservice;
import com.cg.parkingmanagementsystem.service.Parkingslotservice;
import com.cg.parkingmanagementsystem.service.Parkingtransservice;
import com.cg.parkingmanagementsystem.service.VehicleServices;

public class Myapplication {
	static int addid=100;
	public static void main(String[] args) throws SQLException {
		
		//object of all service classes
				
				VehicleServices vehsservice=new VehicleServices();
				Parkingservice parkservice=new Parkingservice();
				Parkingslotservice parkslotservice=new Parkingslotservice();
				Parkingtransservice parktrans=new Parkingtransservice();
				Ownerservice oweserv=new Ownerservice();
			
				
				Owner owew=new Owner();
				Random random=new Random();
				

		int choice=0;
		do{
				Scanner sc=new Scanner(System.in);
				System.out.println("================================================");
				System.out.println();
				System.out.println("========= Parking Management System ===========");
				System.out.println();
				System.out.println("================================================");
				System.out.println("=============== WELCOME ========================");
				System.out.println("1. Add Owner");
				System.out.println("2. Add Vehicles");
				System.out.println("3. Search Vehicles");
				System.out.println("4. Add Parking Location");
				System.out.println("5. Add Parkingslot");
				
				System.out.println("6. Assign Parking");
				System.out.println("7. Exit");
				System.out.println();
				System.out.println("================================================");
			
				choice=sc.nextInt();
				
				
				switch(choice){
				//for adding vehicle  called add(owew)
				case 1: 
					//System.out.println("enter the owner id");
					int id=random.nextInt(1000)+1;
				
					System.out.println("enter the name");
					String owname=sc.next();
					System.out.println("enter the Mobile number");
					String mobno=sc.next();
					//System.out.println("enter the address id");
					int addid=random.nextInt(1000)+1;
					//addid++;
					System.out.println("enter the house no");
					String houseno=sc.next();
					System.out.println("enter the Street");
					String street=sc.next();
					System.out.println("enter the city");
					String city=sc.next();
					System.out.println("enter the Pincode");
					int pincode=sc.nextInt();
					
					//address object for setting into owner
					Address add=new Address(addid,houseno,street,city,pincode);
					
					
					owew.setId(id);
					owew.setName(owname);
					owew.setMobNo(new BigInteger(mobno));
					owew.setAddress(add);
					try {
						oweserv.add(owew);
					} catch (Duplicateaddressuserexception e1) {
						
						System.out.println(e1.getMessage());
					break;
					} catch (SQLException e) {

						e.printStackTrace();
						break;
					}
					

					
					System.out.println("================================");
					System.out.println();
					System.out.println("Owner Added successfully!!!!");
					System.out.println();
					System.out.println("=================================");
				
					
					
					
					
					break;	
					//for adding vehicle  called add(vehice12)
				case 2: 
					
					
					char ch;
					System.out.println("enter the owner id");
					int owwid=sc.nextInt();
					
				do{
					
					//System.out.println("enter the vehicle id");
					int vehid=random.nextInt(1000)+1;
					
					System.out.println("enter vehicle number");
					String vehno=sc.next();
					System.out.println("enter vehicle desciption");
					String vedesc=sc.next();
					
			
					Owner owenew=new Owner(owwid,null,null,null,null);
					
					
					
					
					Vehicle vehice12=new Vehicle(vehid,vehno,vedesc,owenew);
							
						try {
							
								vehsservice.add(vehice12);
							} catch (InvaliddetailId e) {
								System.out.println(e.getMessage());
								break;		} catch (SQLException e) {

								e.printStackTrace();
							} catch (InvalidOwnerId e) {
									// TODO Auto-generated catch block
								System.out.println(e.getMessage());
								break;
								}
						
							
							
						
						
						System.out.println("Do you want to assign another vehicle??  Y/N");
						ch=sc.next().charAt(0);
						System.out.println();
				}while(ch=='Y'||ch=='y');
						
						
						
						System.out.println("================================");
						System.out.println();
						System.out.println("Vehicles Added successfully!!!!");
						System.out.println();
						System.out.println("=================================");
						
						
						break;
						//for searching vehicle searchbyVehNo called
					case 3:
						System.out.println();
						System.out.println("=================================");
						System.out.println("Enter Vehicle number that you want too search");
						String vehNo=sc.next();
					Vehicle vehicle;
					try {
						List<Vehicle> vehicles = vehsservice.searchbyVehNo(vehNo);
						
						System.out.println("Here is your Vehicle detail...");
						System.out.println();
for(Vehicle vehicleee:vehicles) {
						System.out.println(vehicleee.vehicleDetails());
}
						
					} catch (VehicleNotFoundException e) {
						
						System.out.println(e.getMessage());
						break;
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("=================================");
						break;
						//for adding vehicle  called addParking(parki)
					case 4:
						System.out.println("=================================");
					
						
						
						int pid=random.nextInt(1000)+1;
						
					
						System.out.println("enter the Parking Location");
						String plocation=sc.next();
						
						System.out.println("enter Owner ID");
						int powid=sc.nextInt();
						Owner owenew=new Owner(powid,null,null,null,null);
						
						Parking parki=new Parking(pid,plocation,owenew);
				
						
						
						
						
						try {
							parkservice.addParking(parki);
						} catch (com.cg.parkingmanagementsystem.exceptions.InvaliddetailId e) {
							
							System.out.println(e.getMessage());
							break;
						} catch (InvalidOwnerId e) {
							System.out.println(e.getMessage());
							break;
						}
					
						
						System.out.println("Parking location Added successfullly!!!");
						System.out.println();
						/*for(Parking owe:DButil.parking){
							System.out.println("Parking id:- "+owe.getId());
							System.out.println("Parking Location:- "+owe.getLocation());
							
							
						System.out.println("Owner Detail:- "+owe.getOwner().getOwnerDetails());
						System.out.println("=================================");*/
						
					System.out.println("Parking created successfully!!!");
					
					System.out.println("=================================");
						break;
						//for adding vehicle  called createParkingslot(parks)
						
						case 5:
			System.out.println("=================================");
			
			System.out.println("=================================");

			System.out.println("enter the Parking id");
			int pd=sc.nextInt();

			
			
			
			int psid=random.nextInt(1000)+1;
			
			System.out.println("enter the start date for Parkingslot");
			String startdate=sc.next();
			 

		        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		        LocalDate startdate1 = LocalDate.parse(startdate, formatter);
		        
		        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		        
		        
		        System.out.println("enter the end date for Parkingslot");
				String enddate=sc.next();
			
				
				LocalDate enddate1 = LocalDate.parse(enddate, formatter1);
				//LocalDate formatDateTime = LocalDate.parse(enddate, formatter);
			

			
			
			
				DateTimeFormatter formatternew = DateTimeFormatter.ofPattern("HH:mm");
			
			System.out.println("Enter time slot, start time in hrs and minutes:");
			System.out.println("eg. for 10:30 enter 10 hr then press 'Enter key' and enter the minutes 30 ");
		String starttime=sc.next();
		LocalTime  starttime1= LocalTime.parse(starttime, formatternew);

		

		System.out.println("Till how many hrs you want to create ParkingSlot");
		String patternOne=sc.next();


			
			
		
		LocalTime endTime1 = LocalTime.parse(patternOne, formatternew);

		


java.sql.Date sd=java.sql.Date.valueOf(startdate1);
		
		java.sql.Date ed=java.sql.Date.valueOf(enddate1);
		
		
		Time st=Time.valueOf(starttime1);
		
		
		Time et=Time.valueOf(endTime1);
		
		
		
		

		Parking pars=new Parking();
		pars.setId(pd);

		Parkingslot parks=new Parkingslot(psid,pars,sd,ed,st,et);

				
			
			

			
			
			
					
						try {
							parkslotservice.createParkingslot(parks);
						} catch (com.cg.parkingmanagementsystem.exceptions.InvaliddetailId e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
							break;
						} catch (InvalidOwnerId e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
							break;
						}
					
			
						System.out.println("Parking slot created successfullly");
						System.out.println();
						/*for(Parkingslot owe:DButil.parkingslot){
							System.out.println("ParkingSlot ID:- "+owe.getId());
							System.out.println("Parkingslot for "+owe.getParking());
							System.out.print("ParkingSlot creator detail:- "+owe.getParking().getOwner().ownerDetails());
							System.out.println();
							System.out.println("Start date of parkingslot:- "+owe.getStartDate());
							System.out.println("End date of parkingslot:- "+owe.getEndDate());
							System.out.println("Start time of parkingslot:- "+owe.getStartTime());
							System.out.println("End time of parkingslot:- "+owe.getEndTime());						
							System.out.println();
							System.out.println("=================================");
						}*/
						break;
						
						//for adding vehicle  called bookParking(parktranss)
						/*				
		case 6:
					char ch1;
					do {
				
			
			System.out.println("=================================");
			System.out.println();
			System.out.println("Enter parking transaction id");
			int pid1=sc.nextInt();
			
			System.out.println("Enter parkingslot id");
			int id1=sc.nextInt();
			System.out.println();
			System.out.println("Enter Vehicle number");
			String vehNoone=sc.next();

			System.out.println("enter the start date for Parkiing a vehicle");
			System.out.println("enter year");
			int pyear=sc.nextInt();
			System.out.println("enter month");
			int pmonth=sc.nextInt();
			System.out.println("enter day");
			int pday=sc.nextInt();
			
			
			System.out.println("enter the end date for Parkiing a vehicle");
			System.out.println("enter year");
			int pyear1=sc.nextInt();
			System.out.println("enter month");
			int pmonth1=sc.nextInt();
			System.out.println("enter day");
			int pday1=sc.nextInt();

			
			
			
			System.out.println("Enter time slot, start time in hrs and minutes:");
					System.out.println("eg. for 10:30 enter 10 hr then press 'Enter key' and enter the minutes 30 ");
			int patternp=sc.nextInt();

			
			int patterntwop=sc.nextInt();
			
			System.out.println("Till how many hrs you want to park vehicle");
			int patternOnep=sc.nextInt();

			
			System.out.println();
		Vehicle vehee=new Vehicle();
			
			Parkingslot paki=new Parkingslot();

			List<Vehicle> vehicle1;
			try {
				vehicle1 = vehsservice.searchbyVehNo(vehNoone);
for(Vehicle vehic:vehicle1) {
					if(vehic.getnumber().equals(vehNoone)){
						vehee=vehic;
}}
			} catch (VehicleNotFoundException e1) {

				System.out.println(e1.getMessage());
				break;
			} 
			
			List<Parkingslot> park;
			try {
				park = parkslotservice.searchByid(id1);
				for(Parkingslot par:park){
					if(par.getId()==id1) {
						
						paki=par;
						
								}
				}
			} catch (ParkingNotFoundException e1) {
				// TODO Auto-generated catch block
				System.out.println(e1.getMessage());
				break;
			}
			
				
			
			try {
				if(vehee.getnumber()==null || paki.getId()!=id1){
				throw new invaliddetailexcepion("OOPS!!..You have entered the wrong ID or Vehicle Number."
						+ "Please enter the valid detail and try again!!!");}
			} catch (invaliddetailexcepion e) {
				
				System.out.println(e.getMessage());
				break;
			}
			LocalTime pstartTime1 = LocalTime.of(patternp, patterntwop);
			LocalTime pendTime1 = pstartTime1.plusHours(patternOnep);




			LocalDate pstartDate1 = LocalDate.of(pyear,pmonth,pday);
			LocalDate pendDate1 = LocalDate.of(pyear1,pmonth1,pday1);


			Parktransaction parktranss=new Parktransaction(pid1,paki,vehee,pstartDate1,pendDate1,pstartTime1,pendTime1);
			
			
			
					
						
							try {
								parktrans.bookParking(parktranss);
							} catch (com.cg.parkingmanagementsystem.exceptions.InvaliddetailId e) {
								// TODO Auto-generated catch block
								System.out.println(e.getMessage());
								break;
							}
						
						
					 catch (invaliddetailexcepion e) {
						
						System.out.println(e.getMessage());
						break;
					}
						
						System.out.println("Parking assigned to below users successfullly..!!!");
						
						for(Parktransaction owe:DButil.parktrans){
							System.out.println("Parking transaction ID:- "+owe.getId());
							System.out.println(owe.getPk());
							System.out.print(owe.getVeh().vehicleDetails());
							System.out.println();
							System.out.println("Start date:- "+owe.getStartDate());
							System.out.println("End date:- "+owe.getEndDate());
							System.out.println("Start Time:- "+owe.getStartTime());
							System.out.println("End Time:- "+owe.getEndTime());
							System.out.println();			
						}
						System.out.println("================================================");
						
						System.out.println("Do you want to assign another vehicle??  Y/N");
						ch=sc.next().charAt(0);
						System.out.println();
				}while(ch=='Y'||ch=='y');
						break;
					
		case 7:
			System.out.println("======= Thank you ======");
			System.exit(0);
					break;
					
					default:
						System.out.println("Oops..Invalid input."
								+ "Please enter the correct choice from the list!!!");
				*/}
				
			}while(choice!=7);

		}}
