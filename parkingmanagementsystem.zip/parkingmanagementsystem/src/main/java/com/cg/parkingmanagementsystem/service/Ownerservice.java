package com.cg.parkingmanagementsystem.service;

import java.sql.SQLException;

import com.cg.parkingmanagementsystem.dao.Ownerrepository;
import com.cg.parkingmanagementsystem.dto.Address;
import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.exceptions.Duplicateaddressuserexception;

public class Ownerservice implements Ownerserviceinterface{
	Ownerrepository owed;
	static int id=100;
	static int addid=100;
	public Ownerservice() {
	owed=new Ownerrepository();
	
	}
	public Owner add(Owner owe) throws Duplicateaddressuserexception, SQLException {
		
		//owe.setId(id);
		
		
		//owe.getAddress().setid(addid);
		//addid++;
		//id++;
		return owed.save(owe);
	}
	
	
}
