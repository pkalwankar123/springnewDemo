package com.cg.parkingmanagementsystem.exceptions;

public class InvalidOwnerId extends Exception{

public InvalidOwnerId() {}
	
	public InvalidOwnerId(String msg) {
		super(msg);
	}
	
}

