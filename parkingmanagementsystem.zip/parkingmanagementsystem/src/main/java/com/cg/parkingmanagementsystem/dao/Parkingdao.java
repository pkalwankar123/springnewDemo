package com.cg.parkingmanagementsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.parkingmanagementsystem.dbutil.Dbutil;
import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.dto.Parking;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;

public class Parkingdao implements Parkingdaointerface{
	EntityManager em;
	public Parkingdao() {
		em=Dbutil.em;
	}

	public Parking save(Parking parking) throws InvaliddetailId, InvalidOwnerId {

	
		
		
int owner_id=parking.getOwner().getId();
		
		
		
		
		Query queryOne  = em.createQuery("Select a From Owner a where owner_id= :owner_id");
		List<Owner> owner=queryOne.setParameter("owner_id", owner_id).getResultList();
		
	
		
		if(!(owner.isEmpty())) {
			em.getTransaction().begin();
			em.persist(parking);

			em.getTransaction().commit();
			
		}
		//em.persist(vehicle.getOwner());
		
		

		else{
			throw new InvalidOwnerId("OOPS..Owner Not found into the Database."
					+ " Please enter the valid Owner number and try again!!");
		}
		 
		
		/*
		Connection con=DButil.getConnection();
		String query_insert="Insert into parking(id,location,owid) values(?,?,?)";
		String query="Select id from owner where id=?";
		String queryOne="Select id from parking where id=?";
		PreparedStatement pstmone=null;
		PreparedStatement pstm=null;
		PreparedStatement pstmOne=null;
		try {
	
			
			
			pstm=con.prepareStatement(query);
			pstm.setInt(1, park.getOwner().getId());
			ResultSet rs1=pstm.executeQuery();
			
			pstmOne=con.prepareStatement(queryOne);
			pstmOne.setInt(1, park.getId());
			ResultSet rs=pstmOne.executeQuery();
			
		if(rs1.next()==true) {	
		if(rs.next()==false){
			pstmone=con.prepareStatement(query_insert);
			pstmone.setInt(1, park.getId());
			pstmone.setString(2, park.getLocation());
			pstmone.setInt(3, park.getOwner().getId());
				pstmone.executeUpdate();
			
			
			
			}else {
				throw new InvaliddetailId("OOPs, this ParkingID already used. Kindly enter the another Parking id!!");
				
			}
		
		
		
		}
		
			
			else {
				throw new InvaliddetailId("OOPs, You have entered the wrong owner ID. Kindly enter the correct owner id!!");
			}
		
		}
	catch(SQLException e) {
		e.printStackTrace();
			
		}*/
	return parking;	
		
	}
	
}


