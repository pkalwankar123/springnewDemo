package com.cg.parkingmanagementsystem.exceptions;

public class Duplicateaddressuserexception extends Exception {


	public Duplicateaddressuserexception() {
		
	}
	public Duplicateaddressuserexception(String msg) {
		super(msg);
	}
}

