package com.cg.parkingmanagementsystem.dao;

import java.sql.SQLException;

import com.cg.parkingmanagementsystem.dto.Parktransaction;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.invaliddetailexcepion;

public interface Parkingttransdaointerface {
	public Parktransaction book(Parktransaction park) throws invaliddetailexcepion, InvaliddetailId, SQLException;
}
