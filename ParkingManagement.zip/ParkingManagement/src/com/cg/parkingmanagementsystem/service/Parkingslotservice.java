package com.cg.parkingmanagementsystem.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.cg.parkingmanagementsystem.Util.DButil;
import com.cg.parkingmanagementsystem.dao.Parkinslotdao;
import com.cg.parkingmanagementsystem.dto.Parkingslot;

public class Parkingslotservice implements Parkingslotinterface{

	Parkinslotdao parslotdao;
	
	public Parkingslotservice() {
		parslotdao=new Parkinslotdao();
	}
	
	
	
	@Override
	public void createParkingSlot(Parkingslot parkSlot) {
		// TODO Auto-generated method stub
		
		
		parslotdao.saveParkingSlot(parkSlot);
	}

	@Override
	public List<Parkingslot> searchParkingSlotbyDate(LocalDate startDate, Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Parkingslot> removeParkingSlot(Parkingslot parkSlot) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public List<Parkingslot> searchParkingSlotbyDate(Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}

}
