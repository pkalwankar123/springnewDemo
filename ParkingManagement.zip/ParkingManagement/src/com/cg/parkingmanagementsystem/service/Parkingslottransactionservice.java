package com.cg.parkingmanagementsystem.service;

import java.util.Map;

import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.dto.Parkingslottransaction;
import com.cg.parkingmanagementsystem.dto.Vehicle;

public interface Parkingslottransactionservice {
	
	

	public  Parkingslottransaction bookParking(Integer id, String vehno);
	
	
	
	

}
