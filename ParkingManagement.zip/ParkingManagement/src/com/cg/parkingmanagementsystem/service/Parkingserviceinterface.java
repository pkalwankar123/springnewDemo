package com.cg.parkingmanagementsystem.service;

import java.util.List;
import java.util.Map;

import com.cg.parkingmanagementsystem.dto.Parking;



public interface Parkingserviceinterface {
	
	public void addParking(Parking park);
	
	
	

}
