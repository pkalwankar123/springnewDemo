package com.cg.parkingmanagementsystem.service;

import java.util.Map;

import com.cg.parkingmanagementsystem.dao.Parkingslottransactiondao;
import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.dto.Parkingslottransaction;
import com.cg.parkingmanagementsystem.dto.Vehicle;

public class Parkingslottransactionservices implements Parkingslottransactionservice{

	
	Parkingslottransactiondao pk=new Parkingslottransactiondao();
	
	@Override
	public Parkingslottransaction bookParking(Integer id,String vehno) {

		
	
		pk.bookParking(id, vehno);
		
		return null;
	}

	
}
