package com.cg.parkingmanagementsystem.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.cg.parkingmanagementsystem.dto.Parkingslot;



public interface Parkingslotinterface {
	
	public void createParkingSlot(Parkingslot parkSlot);
	public List<Parkingslot> searchParkingSlotbyDate(Date startDate, Date endDate);
	public List<Parkingslot> removeParkingSlot(Parkingslot parkSlot);
	List<Parkingslot> searchParkingSlotbyDate(LocalDate startDate, Date endDate);
	
	

}
