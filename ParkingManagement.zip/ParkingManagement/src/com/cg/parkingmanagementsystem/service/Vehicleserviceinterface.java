package com.cg.parkingmanagementsystem.service;

import java.util.List;


import com.cg.parkingmanagementsystem.dto.Vehicle;


public interface Vehicleserviceinterface {
	
	public void addVehicles(Vehicle veh);
	public Vehicle searchByVehNo(String vehNo);
	

}
