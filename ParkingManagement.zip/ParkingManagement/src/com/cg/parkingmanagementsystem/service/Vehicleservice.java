package com.cg.parkingmanagementsystem.service;

import java.util.List;

import com.cg.parkingmanagementsystem.dao.Vehicledao;
import com.cg.parkingmanagementsystem.dto.Vehicle;

public class Vehicleservice implements Vehicleserviceinterface{
	Vehicledao vehicles;
	public Vehicleservice(){
		
		vehicles=new Vehicledao();
		
	}
	
	
	
	@Override
	public void addVehicles(Vehicle veh) {
		// TODO Auto-generated method stub
		
		vehicles.save(veh);
		
	}

	@Override
	public Vehicle searchByVehNo(String vehNo) {
		// TODO Auto-generated method stub
		return vehicles.findByVehNo(vehNo);
	}



	

}
