package com.cg.parkingmanagementsystem.service;

import java.util.Iterator;
import java.util.List;

import com.cg.parkingmanagementsystem.Util.DButil;
import com.cg.parkingmanagementsystem.dao.Parkingdao;
import com.cg.parkingmanagementsystem.dto.Parking;

public class Parkingservice implements Parkingserviceinterface{

	Parkingdao parkingdao;
	
	public Parkingservice() {
		
		parkingdao=new Parkingdao();
		
	}
	@Override
	public void addParking(Parking park) {
		// TODO Auto-generated method stub
		
		parkingdao.saveParking(park);
		
	}
	

}
