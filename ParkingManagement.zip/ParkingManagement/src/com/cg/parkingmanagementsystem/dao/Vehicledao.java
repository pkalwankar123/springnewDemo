package com.cg.parkingmanagementsystem.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.parkingmanagementsystem.Util.DButil;
import com.cg.parkingmanagementsystem.dto.Vehicle;

public class Vehicledao implements Vehicledaointerface{
	

	
	@Override
	public Vehicle save(Vehicle vehicle) {
		
DButil.vehicle.add(vehicle);

		
		return vehicle;
	}


	@Override
	public Vehicle findByVehNo(String vehNo) {
		// TODO Auto-generated method stub
		
		for(Vehicle veh: DButil.vehicle){
			if(veh.getVehNo().equals(vehNo)){
				return veh;
			}
		}
		
		
		return null;
	}
	

}
