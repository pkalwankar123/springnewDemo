package com.cg.parkingmanagementsystem.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.parkingmanagementsystem.Util.DButil;
import com.cg.parkingmanagementsystem.dto.Parkingslot;

public class Parkinslotdao implements Parkinslotdaointerface{

	
	
	
	
	
	@Override
	public Parkingslot saveParkingSlot(Parkingslot parkSlot) {

		DButil.parkingslot.put(parkSlot.getId(), parkSlot);
		
		return parkSlot;
	}

	@Override
	public List<Parkingslot> findParkingSlotbyDate(Date startDate, Date endDate) {

		return null;
	}

	@Override
	public List<Parkingslot> updateParkingSlot(Parkingslot parkSlot) {

		return null;
	}

}
