package com.cg.parkingmanagementsystem.dao;

import java.util.List;
import java.util.Map;

import com.cg.parkingmanagementsystem.dto.Parking;


public interface Parkingdaointerface {
	
	public Parking saveParking(Parking park);
	
}
