package com.cg.parkingmanagementsystem.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.cg.parkingmanagementsystem.Util.DButil;
import com.cg.parkingmanagementsystem.dto.Parking;
import com.cg.parkingmanagementsystem.dto.Vehicle;

public class Parkingdao implements Parkingdaointerface{

	
	
	
	
	
	@Override
	public Parking saveParking(Parking park) {
		// TODO Auto-generated method stub
		DButil.parking.put(park.getId(), park);
		return null;
	}


	

}

