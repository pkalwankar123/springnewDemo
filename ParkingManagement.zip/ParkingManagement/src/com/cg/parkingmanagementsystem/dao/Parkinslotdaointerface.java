package com.cg.parkingmanagementsystem.dao;

import java.util.Date;
import java.util.List;

import com.cg.parkingmanagementsystem.dto.Parkingslot;

public interface Parkinslotdaointerface {
	
	public Parkingslot saveParkingSlot(Parkingslot parkSlot);
	public List<Parkingslot> findParkingSlotbyDate(Date startDate, Date endDate);
	public List<Parkingslot> updateParkingSlot(Parkingslot parkSlot);

}
