package com.cg.parkingmanagementsystem.dao;

import java.util.List;


import com.cg.parkingmanagementsystem.dto.Vehicle;

public interface Vehicledaointerface {
	
	public Vehicle save(Vehicle vehicle);
	public Vehicle findByVehNo(String vehNo);
	

}
