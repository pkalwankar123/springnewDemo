package com.cg.parkingmanagementsystem.dao;

import java.util.Map;

import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.dto.Parkingslottransaction;
import com.cg.parkingmanagementsystem.dto.Vehicle;
import com.cg.parkingmanagementsystem.service.Parkingslottransactionservice;

public interface Parkingslottransactiondaointerface {

	
	
	public Parkingslottransaction bookParking(Integer id, String vehno);
	
	
	
}
