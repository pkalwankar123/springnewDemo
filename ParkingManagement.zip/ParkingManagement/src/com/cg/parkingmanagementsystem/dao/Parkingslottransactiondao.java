package com.cg.parkingmanagementsystem.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cg.parkingmanagementsystem.Util.DButil;
import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.dto.Parkingslottransaction;
import com.cg.parkingmanagementsystem.dto.Vehicle;
import com.cg.parkingmanagementsystem.service.Parkingslottransactionservice;
import com.cg.parkingmanagementsystem.service.Vehicleservice;

public class Parkingslottransactiondao implements Parkingslottransactiondaointerface{
	Parkingslottransaction parkingslottransaction;
	Vehicle veh;
	
	public Parkingslottransactiondao() {
		parkingslottransaction=new Parkingslottransaction();
		veh=new Vehicle();
	}
	
	
	Vehicleservice vehs=new Vehicleservice();
	
	Parkingslot pa=new  Parkingslot();
	@Override
	public Parkingslottransaction bookParking(Integer id, String vehno) {
		
	Map<Parkingslot, Vehicle> parkingslot1=new HashMap<Parkingslot, Vehicle>();
		
		
		
		if(DButil.parkingslot.containsKey(id)) {
			
		
		if(DButil.vehicles.containsKey(vehno)) {
		
		
			//parkingslot1.put(id, vehno);
			
			
			
		
			
		
		}
		
		
		
		
	
	}
		return null;
		

	}
	
	
}
