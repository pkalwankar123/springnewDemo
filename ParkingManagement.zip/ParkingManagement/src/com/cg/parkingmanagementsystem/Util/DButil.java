package com.cg.parkingmanagementsystem.Util;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.parkingmanagementsystem.dto.Address;
import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.dto.Parking;
import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.dto.Parkingslottransaction;
import com.cg.parkingmanagementsystem.dto.Vehicle;

public class DButil {
	public static List<Owner> owner=new ArrayList<Owner>();
	public static List<Vehicle> vehicle=new ArrayList<Vehicle>();
	public static List<Parking> parking=new ArrayList<Parking>();
	public static List<Parkingslot> parkingslot=new ArrayList<Parkingslot>();
	public static List<Parktransaction> parktrans=new ArrayList<Parktransaction>();

}
