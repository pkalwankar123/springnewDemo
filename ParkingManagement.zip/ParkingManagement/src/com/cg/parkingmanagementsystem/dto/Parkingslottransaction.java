package com.cg.parkingmanagementsystem.dto;

import java.time.LocalTime;
import java.util.Date;

public class Parkingslottransaction {

	private Vehicle vehicle;
	private Parkingslot parkingSlot;
	private Date startDate;
	private Date endtDate;
	private LocalTime startTime;
	private LocalTime endTime;
	
	public  Parkingslottransaction() {}

	public Parkingslottransaction(Vehicle vehicle, Parkingslot parkingSlot, Date startDate, Date endtDate,
			LocalTime startTime, LocalTime endTime) {
		super();
		this.vehicle = vehicle;
		this.parkingSlot = parkingSlot;
		this.startDate = startDate;
		this.endtDate = endtDate;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public Parkingslot getParkingSlot() {
		return parkingSlot;
	}

	public void setParkingSlot(Parkingslot parkingSlot) {
		this.parkingSlot = parkingSlot;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndtDate() {
		return endtDate;
	}

	public void setEndtDate(Date endtDate) {
		this.endtDate = endtDate;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	public LocalTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}

	@Override
	public String toString() {
		return "ParkingSlotTransaction [vehicle=" + vehicle + ", parkingSlot=" + parkingSlot + ", startDate="
				+ startDate + ", endtDate=" + endtDate + ", startTime=" + startTime + ", endTime=" + endTime + "]";
	}
	


}
