package com.cg.parkingmanagementsystem.dto;

public class Address {
	
	private String street;
	private String houseNo;
	private int pincode;
	private String city;
	
	
	public  Address() {}
	
	public Address(String street, String houseNo, int pincode, String city) {
		super();
		this.street = street;
		this.houseNo = houseNo;
		this.pincode = pincode;
		this.city = city;
	}

	public String getArea() {
		return street;
	}

	public void setArea(String street) {
		this.street = street;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "[area=" + street + ", houseNo=" + houseNo + ", pincode=" + pincode + ", city=" + city + "]";
	}


	



	
	
}
