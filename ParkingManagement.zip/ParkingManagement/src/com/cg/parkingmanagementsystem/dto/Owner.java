package com.cg.parkingmanagementsystem.dto;


import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import com.cg.parkingmanagementsystem.Util.DButil;

public class Owner {

	private String name;
	private BigInteger mobNo;
	private Map<String, Vehicle> vehicle;
	private Address address;
	
	public Owner(){}
	
	public Owner(String name, BigInteger mobNo, Map<String, Vehicle> vehicle, Address address) {
		super();
		this.name = name;
		this.mobNo = mobNo;
		this.vehicle = vehicle;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigInteger getMobNo() {
		return mobNo;
	}

	public void setMobNo(BigInteger mobNo) {
		this.mobNo = mobNo;
	}

	public Map<String, Vehicle> getVehicle() {
		return vehicle;
	}

	public void setVehicle(Map<String, Vehicle> vehicles) {
		this.vehicle = vehicles;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Owner [name=" + name + ", mobNo=" + mobNo + ", vehicle=" + vehicle + ", address=" + address + "]";
	}

	
	
	
	
}

	
	

