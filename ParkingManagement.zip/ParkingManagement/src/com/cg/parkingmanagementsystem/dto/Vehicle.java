package com.cg.parkingmanagementsystem.dto;


	
	
	public class Vehicle {

		private int vehId;
		private String vehNo;
		private String vehDesc;
		private Owner owner;
		


		public  Vehicle() {}

		public Vehicle(int vehId, String vehNo, String vehDesc, Owner owner) {
			super();
			this.vehId = vehId;
			this.vehNo = vehNo;
			this.vehDesc = vehDesc;
			this.owner = owner;
		}

		
		public int getVehId() {
			return vehId;
		}


		public void setVehId(int vehId) {
			this.vehId = vehId;
		}


		public String getVehNo() {
			return vehNo;
		}


		public void setVehNo(String vehNo) {
			this.vehNo = vehNo;
		}


		public String getVehDesc() {
			return vehDesc;
		}


		public void setVehDesc(String vehDesc) {
			this.vehDesc = vehDesc;
		}


		public Owner getOwner() {
			return owner;
		}


		public void setOwner(Owner owner) {
			this.owner = owner;
		}

		@Override
		public String toString() {
			return "[vehId=" + vehId + ", vehNo=" + vehNo + ", vehDesc=" + vehDesc + ", owner=" + owner + "]";
		}


		
		
	}



