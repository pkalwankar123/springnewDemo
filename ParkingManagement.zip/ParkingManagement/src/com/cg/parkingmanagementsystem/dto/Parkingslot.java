package com.cg.parkingmanagementsystem.dto;

import java.time.LocalTime;
import java.util.Date;

public class Parkingslot {

	private int id;
	private Parking parking;
	private Date startDate;
	private Date endtDate;
	private LocalTime startTime;
	private LocalTime endTime;
	
	public  Parkingslot() {}

	public Parkingslot(int id, Parking parking, Date startDate, Date endtDate, LocalTime startTime, LocalTime endTime) {
		super();
		this.id = id;
		this.parking = parking;
		this.startDate = startDate;
		this.endtDate = endtDate;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Parking getParking() {
		return parking;
	}

	public void setParking(Parking parking) {
		this.parking = parking;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndtDate() {
		return endtDate;
	}

	public void setEndtDate(Date endtDate) {
		this.endtDate = endtDate;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	public LocalTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}

	@Override
	public String toString() {
		return "ParkingSlot [id=" + id + ", parking=" + parking + ", startDate=" + startDate + ", endtDate=" + endtDate
				+ ", startTime=" + startTime + ", endTime=" + endTime + "]";
	}


}
