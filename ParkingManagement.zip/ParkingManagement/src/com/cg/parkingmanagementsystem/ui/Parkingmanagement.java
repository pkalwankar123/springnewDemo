package com.cg.parkingmanagementsystem.ui;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.parkingmanagementsystem.dto.Address;
import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.dto.Parking;
import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.dto.Vehicle;
import com.cg.parkingmanagementsystem.service.Parkingservice;
import com.cg.parkingmanagementsystem.service.Parkingslotservice;
import com.cg.parkingmanagementsystem.service.Parkingtransservice;
import com.cg.parkingmanagementsystem.service.VehicleServices;
import com.cg.parkingmanagementsystem.util.DButil;

public class Myapplication {

	public static void main(String[] args) {
		
		VehicleServices vehsservice=new VehicleServices();
		Parkingservice parkservice=new Parkingservice();
		Parkingslotservice parkslotservice=new Parkingslotservice();
		Parkingtransservice parktrans=new Parkingtransservice();
		
		Owner ownerOne=new Owner();
		Owner ownerTwo=new Owner();
		Address address=new Address(443,"Mankhurd","Mumbai",400088);
		Address addressOne=new Address(420,"vashi","NaviMumbai",4000706);
		
		
		
		ownerOne.setName("Pradip");	
		ownerOne.setMobNo(new BigInteger("7506271166"));	
		ownerOne.setAddress(address);

		ownerTwo.setName("Danish");	
		ownerTwo.setMobNo(new BigInteger("7776968917"));	
		ownerTwo.setAddress(addressOne);

		
	
		
			
			Vehicle vehice=new Vehicle(1,"MH03CA1256","Audi800",ownerOne);
			Vehicle vehiceOne=new Vehicle(2,"MH12BD5533","BMW-R8",ownerOne);
			
			Vehicle vehiceTwo=new Vehicle(1,"MH17CA9555","Maruti800",ownerTwo);
			Vehicle vehiceThree=new Vehicle(2,"MH11BD1241","Alto",ownerTwo);
			
			
		List<Vehicle> veh=new ArrayList<Vehicle>();
		veh.add(vehice);
		veh.add(vehiceOne);
		ownerOne.setVehicles(veh);
		
		
		List<Vehicle> veh1=new ArrayList<Vehicle>();
		veh1.add(vehiceTwo);
		veh1.add(vehiceThree);
		ownerTwo.setVehicles(veh1);
		
		DButil.owner.add(ownerOne);
		DButil.owner.add(ownerTwo);
		
		
		Parking parking=new Parking(1,"Talwade",ownerOne);
		
		LocalTime startTime = LocalTime.of(8,30,15);
		LocalTime endTime = startTime.plusHours(8);
		LocalDate startDate = LocalDate.of(2019, 12, 10);
		LocalDate endDate = LocalDate.of(2019, 12, 10);
		
		Parkingslot parkingslot=new Parkingslot(1,parking,startDate,endDate,startTime,endTime);
		
		
		
int choice=0;
		
	


do{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter your choice");
		System.out.println("1. add vehicle");
		System.out.println("2. search vehicle");
		System.out.println("3. Add Parking");
		System.out.println("4. Add Parkingslot");
		choice=sc.nextInt();
		
		
		switch(choice){
			case 1: 
				vehsservice.add(vehice);
				vehsservice.add(vehiceOne);
				
				vehsservice.add(vehiceTwo);
				vehsservice.add(vehiceThree);
		
				System.out.println("Vehicles Added successfully!!!!");
		
				
				for(Vehicle owe:DButil.vehicle){
					System.out.println(owe.getVehId());
					System.out.println(owe.getVehNo());
					System.out.println(owe.getVehDesc());
				System.out.println(owe.getOwner().getOwnerDetails());		
				}
				break;
			case 2:
				System.out.println("Enter Vehicle number that  you want too search");
				String vehNo=sc.next();
				Vehicle vehicle=vehsservice.searchbyVehNo(vehNo);
				System.out.println(vehicle.vehicleDetails());
				break;
			case 3:
				
				parkservice.addParking(parking);
				
				System.out.println("Parking Added successfullly");
				
				for(Parking owe:DButil.parking){
					System.out.println(owe.getLocation());
					System.out.println(owe.getId());
					
				System.out.println(owe.getOwner().getOwnerDetails());		
				}
				break;
case 4:
				
	parkslotservice.createParkingslot(parkingslot);
				
				System.out.println("Parking slot created successfullly");
				
				for(Parkingslot owe:DButil.parkingslot){
					System.out.println(owe.getId());
					System.out.println(owe.getParking());
					System.out.print(owe.getParking().getOwner().ownerDetails());
					System.out.println(owe.getStartDate());
					System.out.println(owe.getEndDate());
					System.out.println(owe.getStartTime());
					System.out.println(owe.getEndTime());
						
				}
				break;
				
case 5:
	System.out.println("Enter parking id");
	int id=sc.nextInt();

	
	System.out.println("Enter Vehicle number");
	String vehNoone=sc.next();
	Vehicle vehicle=parktrans.bookParking(partrns);
	parktrans.bookParking();
				
				System.out.println("Parking slot created successfullly");
				
				for(Parkingslot owe:DButil.parkingslot){
					System.out.println(owe.getId());
					System.out.println(owe.getParking());
					System.out.print(owe.getParking().getOwner().ownerDetails());
					System.out.println(owe.getStartDate());
					System.out.println(owe.getEndDate());
					System.out.println(owe.getStartTime());
					System.out.println(owe.getEndTime());
						
				}
				break;
				
				
				
		}
		
	}while(choice!=6);

}}
