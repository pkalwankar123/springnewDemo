package com.cg.accountcustomer.customerAccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerAccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
