package com.cg.accountcustomer.customerAccount.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.accountcustomer.customerAccount.model.Account;
import com.cg.accountcustomer.customerAccount.model.Deposite;
import com.cg.accountcustomer.customerAccount.model.Saving;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
    Saving findBysavingAccountNumber(String accountnumber);
    Deposite findByDepositeAccountNumber(String accountnumber);
	void save(Saving fromSavingAccount);
	void save(Deposite toDepositeAccount);
	Saving findByAccountNumberEqualsandAccountid(String accountNumber,long accid);
	Deposite findByAccountNumberEqualsandAccountid1(String accountNumber,long accid);

}
