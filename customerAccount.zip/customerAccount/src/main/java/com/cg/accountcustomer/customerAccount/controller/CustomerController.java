package com.cg.accountcustomer.customerAccount.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.cg.accountcustomer.customerAccount.model.AccountStatementRequest;
import com.cg.accountcustomer.customerAccount.model.Customer;
import com.cg.accountcustomer.customerAccount.model.Response;
import com.cg.accountcustomer.customerAccount.model.TransferBalanceRequest;
import com.cg.accountcustomer.customerAccount.service.AccountService;


@RestController
@RequestMapping("/customerAccount")
public class CustomerController {

	    @Autowired
	    private AccountService accountService;
	    
	   @RequestMapping("/add")
	    public void create(@RequestBody Customer customer) {
	        accountService.save(customer);
	        
	    }

	
	    @RequestMapping("/sendmoney")
	    public Response sendMoney(
	            @RequestBody TransferBalanceRequest transferBalanceRequest
	            ) {

	        return Response.ok().setPayload(
	                accountService.sendMoney(
	                        transferBalanceRequest
	                )
	        );
	    }
	    @RequestMapping("/statement")
	    public Response getStatement(
	            @RequestBody AccountStatementRequest accountStatementRequest

	    ){
	        return Response.ok().setPayload(
	                accountService.getStatement(accountStatementRequest.getAccountNumber(), accountStatementRequest.getAccId())
	        );

	    }

	}
