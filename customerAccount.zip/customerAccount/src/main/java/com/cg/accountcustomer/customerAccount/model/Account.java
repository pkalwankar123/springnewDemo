package com.cg.accountcustomer.customerAccount.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name="account")
public class Account {

	
@Id
@GeneratedValue
private Long accountId;
@OneToOne(mappedBy = "account", fetch = FetchType.LAZY,
cascade = CascadeType.ALL)
@Column(name="savingType")
private Saving saving;
@Column(name="depositeType")
private Deposite deposit;

@ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "cust_id", nullable = false)
private Customer customer;


}
