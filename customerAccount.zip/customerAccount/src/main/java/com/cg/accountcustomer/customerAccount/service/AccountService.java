package com.cg.accountcustomer.customerAccount.service;

import com.cg.accountcustomer.customerAccount.model.AccountStatement;
import com.cg.accountcustomer.customerAccount.model.Customer;
import com.cg.accountcustomer.customerAccount.model.Transaction;
import com.cg.accountcustomer.customerAccount.model.TransferBalanceRequest;



public interface AccountService {
	
	  //List<Account> findAll();
	Customer save(Customer customer);
	  
//	  Account save(Account account);
	    Transaction sendMoney(
	            TransferBalanceRequest transferBalanceRequest
	    );

		AccountStatement getStatement(String accountNumber, long accountId);

	
	

}
