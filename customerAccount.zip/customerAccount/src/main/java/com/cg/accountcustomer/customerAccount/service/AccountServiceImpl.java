package com.cg.accountcustomer.customerAccount.service;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cg.accountcustomer.customerAccount.dao.AccountRepository;
import com.cg.accountcustomer.customerAccount.dao.CustomerRepository;
import com.cg.accountcustomer.customerAccount.dao.TransactionRepository;
import com.cg.accountcustomer.customerAccount.model.Account;
import com.cg.accountcustomer.customerAccount.model.AccountStatement;
import com.cg.accountcustomer.customerAccount.model.Customer;
import com.cg.accountcustomer.customerAccount.model.Deposite;
import com.cg.accountcustomer.customerAccount.model.Saving;
import com.cg.accountcustomer.customerAccount.model.Transaction;
import com.cg.accountcustomer.customerAccount.model.TransferBalanceRequest;


@Service
public class AccountServiceImpl implements AccountService {
@Autowired
private AccountRepository accountRepository;

@Autowired
private CustomerRepository customerRepository;

@Autowired
TransactionRepository transactionRepository;

public Customer save(Customer customer){
	customerRepository.save(customer);
    return customerRepository.findByCustomerId(customer.getId());
}

/*public List<Account> findAll(){
    return accountRepository.findAll();
}

public Customer findByCustomerId(String accountNumber){
    Account account = customerRepository.findByAccountNumberEquals(accountNumber);
    return account;
}

*/
@Override
public Transaction sendMoney(
        TransferBalanceRequest transferBalanceRequest
) {
    String fromAccountNumber = transferBalanceRequest.getFromAccountNumber();
    String toAccountNumber = transferBalanceRequest.getToAccountNumber();
    BigDecimal amount = transferBalanceRequest.getAmount();
    Saving fromSavingAccount = accountRepository.findBysavingAccountNumber(fromAccountNumber);
    Deposite fromDepositeAccount = accountRepository.findByDepositeAccountNumber(fromAccountNumber);
    
   
    Saving toSavingAccount = accountRepository.findBysavingAccountNumber(toAccountNumber);
    Deposite toDepositeAccount = accountRepository.findByDepositeAccountNumber(toAccountNumber);  
    
    if(fromSavingAccount!=null) {
    	 if((fromSavingAccount.getCurrentBalance().compareTo(BigDecimal.ONE) == 1
    	            && fromSavingAccount.getCurrentBalance().compareTo(amount) == 1)){
    		 fromSavingAccount.setCurrentBalance(fromSavingAccount.getCurrentBalance().subtract(amount));
    	        accountRepository.save(fromSavingAccount);
    	        
    	        if(toSavingAccount!=null) {
    	        	toSavingAccount.setCurrentBalance(toSavingAccount.getCurrentBalance().add(amount));
        	        accountRepository.save(toSavingAccount);
    	        }
    	        else {
    	        	toDepositeAccount.setCurrentBalance(toDepositeAccount.getCurrentBalance().add(amount));
        	        accountRepository.save(toDepositeAccount);
    	        }
    	        Transaction transaction = transactionRepository.save(new Transaction(0L,fromAccountNumber,amount,new Timestamp(System.currentTimeMillis())));
    	        return transaction;
    	 }
    	
    }
    else {
    	if((fromDepositeAccount.getCurrentBalance().compareTo(BigDecimal.ONE) == 1
	            && fromDepositeAccount.getCurrentBalance().compareTo(amount) == 1)){
    		fromDepositeAccount.setCurrentBalance(fromDepositeAccount.getCurrentBalance().subtract(amount));
	        accountRepository.save(fromDepositeAccount);
	        
	        if(toSavingAccount!=null) {
	        	toSavingAccount.setCurrentBalance(toSavingAccount.getCurrentBalance().add(amount));
    	        accountRepository.save(toSavingAccount);
	        }
	        else {
	        	toDepositeAccount.setCurrentBalance(toDepositeAccount.getCurrentBalance().add(amount));
    	        accountRepository.save(toDepositeAccount);
	        }
	        Transaction transaction = transactionRepository.save(new Transaction(0L,fromAccountNumber,amount,new Timestamp(System.currentTimeMillis())));
	        return transaction;
	 }
	 }
    
  
    return null;
}

@Override
public AccountStatement getStatement(String accountNumber,long accountId) {
    Saving savingAccount = accountRepository.findByAccountNumberEqualsandAccountid(accountNumber, accountId);
    Deposite depositeAccount= accountRepository.findByAccountNumberEqualsandAccountid1(accountNumber, accountId);
    if(savingAccount!=null && savingAccount.getAccountNumber().equalsIgnoreCase(accountNumber) && savingAccount.getAccount().getAccountId()==accountId) {
    	return new AccountStatement(savingAccount.getCurrentBalance(),transactionRepository.findByAccountNumberEquals(accountNumber));
    }
    else {
    	return new AccountStatement(depositeAccount.getCurrentBalance(),transactionRepository.findByAccountNumberEquals(accountNumber));
    	   
    }
   
}



}