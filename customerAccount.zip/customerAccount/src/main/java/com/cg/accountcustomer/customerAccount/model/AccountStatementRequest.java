package com.cg.accountcustomer.customerAccount.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
public class AccountStatementRequest  {
	private String accountNumber;
	private long accId;
}
